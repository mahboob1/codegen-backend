package com.mhc.iamservice.model;

public enum Role {
    USER,
    ADMIN
}


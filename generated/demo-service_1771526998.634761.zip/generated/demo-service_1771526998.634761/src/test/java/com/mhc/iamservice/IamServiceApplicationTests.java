package com.mhc.iamservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IamServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
